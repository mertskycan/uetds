<?php $__env->startSection('content'); ?>
    <!-- TOP Nav Bar END -->
    <div class="container-fluid">
        <div class="row">
           <div class="col-sm-12">
              <div class="iq-card">
                 <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                       <h4 class="card-title">Şöför Listesi</h4>
                    </div>
                 </div>
                 <div class="iq-card-body">
                    <p></p>
                    <div class="table-responsive">
                       <table id="datatable" class="table table-striped table-bordered" >
                          <thead>
                            <tr>
                                <th>Firma Adı</th>
                                <th>Sürücü Adı</th>
                                <th>Sürücü Soyadı</th>
                                <th>Telefon</th>
                                <th>E-posta</th>
                                <th>Oluşturulma Tarihi
                                </th>
                                <th></th>
                             </tr>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $SoforModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->company->name); ?></td>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->surname); ?></td>
                                <td><?php echo e($item->phone); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e(date_format($item->created_at, 'm/d/Y')); ?></td>
                                <td>
                                    <form action="<?php echo e(route('sofor.destroy', $item->id)); ?>" method="POST">

                                        <a href="<?php echo e(route('sofor.show', $item->id)); ?>" title="show">
                                            <i class="ri-eye-fill text-success fa-lg"></i>
                                        </a>

                                        <a href="<?php echo e(route('sofor.edit', $item->id)); ?>">
                                            <i class="ri-pencil-fill  fa-lg"></i>

                                        </a>

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit" title="delete" style="border: none; background-color:transparent;">
                                            <i class="ri-delete-bin-2-fill  fa-lg text-danger"></i>

                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

</tfoot>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
    <?php echo $SoforModel->links(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uetds\resources\views/Sofor/index.blade.php ENDPATH**/ ?>