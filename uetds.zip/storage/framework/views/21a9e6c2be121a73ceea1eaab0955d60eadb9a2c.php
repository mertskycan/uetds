<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
       <div class="col-sm-12 col-lg-12">
          <div class="iq-card">
             <div class="iq-card-header d-flex justify-content-between">
                <div class="iq-header-title">
                   <h4 class="card-title">Plaka Oluştur</h4>
                </div>
             </div>
             <div class="iq-card-body">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi vulputate, ex ac venenatis mollis, diam nibh finibus leo</p>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <strong>Whoops!</strong> There were some problems with your input.<br><br>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('plaka.store')); ?>" method="POST" >
                <?php echo csrf_field(); ?>
                <div class="form-group form-row">
                   <div class="col">
                       <label for="name">Plaka</label>
                      <input type="text" class="form-control"  id="plate" name="plate" placeholder=" ">
                   </div>
                   <div class="col">
                    <label for="company_id">Firma</label>

                    <select class="form-control" id="company_id"name="company_id" >
                       <option selected="" disabled="">Firma Seçiniz</option>
                       <?php ( $companys = \App\CompanyModel::get()); ?>
                        <?php $__currentLoopData = $companys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                   </div>
                </div>





                      <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" class="form-control"  id="created_user_id" name="created_user_id" >

                   <button type="submit" class="btn btn-primary">Kaydet </button>
                   <button type="submit" class="btn iq-bg-danger">Cancel</button>
                </form>
             </div>
          </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uetds\resources\views/Plaka/create.blade.php ENDPATH**/ ?>