<?php $__env->startSection('content'); ?>
    <!-- TOP Nav Bar END -->
    <div class="container-fluid">
        <div class="row">
           <div class="col-sm-12">
              <div class="iq-card">
                 <div class="iq-card-header d-flex justify-content-between">
                    <div class="iq-header-title">
                       <h4 class="card-title">Bootstrap Datatables</h4>
                    </div>
                 </div>
                 <div class="iq-card-body">
                    <p>Images in Bootstrap are made responsive with <code>.img-fluid</code>. <code>max-width: 100%;</code> and <code>height: auto;</code> are applied to the image so that it scales with the parent element.</p>
                    <div class="table-responsive">
                       <table id="datatable" class="table table-striped table-bordered" >
                          <thead>
                             <tr>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Office</th>
                                <th>Age</th>
                                <th>Start date</th>
                                <th>Salary</th>
                             </tr>
                          </thead>
                          <tbody>
                            <?php $__currentLoopData = $SeferModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$i); ?></td>
                                <td><?php echo e($project->name); ?></td>
                                <td><?php echo e($project->introduction); ?></td>
                                <td><?php echo e($project->location); ?></td>
                                <td><?php echo e($project->cost); ?></td>
                                <td><?php echo e(date_format($project->created_at, 'jS M Y')); ?></td>
                                <td>
                                    <form action="<?php echo e(route('sefer.destroy', $project->id)); ?>" method="POST">

                                        <a href="<?php echo e(route('sefer.show', $project->id)); ?>" title="show">
                                            <i class="fas fa-eye text-success  fa-lg"></i>
                                        </a>

                                        <a href="<?php echo e(route('sefer.edit', $project->id)); ?>">
                                            <i class="fas fa-edit  fa-lg"></i>

                                        </a>

                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="submit" title="delete" style="border: none; background-color:transparent;">
                                            <i class="fas fa-trash fa-lg text-danger"></i>

                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

</tfoot>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
    <?php echo $SeferModel->links(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\uetds\resources\views/Sefer/index.blade.php ENDPATH**/ ?>